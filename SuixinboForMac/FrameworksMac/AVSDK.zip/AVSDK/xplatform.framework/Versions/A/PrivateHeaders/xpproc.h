/******************************************************************
 ** File 		: */place_your_file_name_here/*.h
 ** Author		: */place_your_name_here/*
 ** Date		: */place_created_date_here/*
 ** Copyright	: Copyright (c) 2012-2014 Tencent Co.,Ltd.
 ** Description	: */write_description_here/*
 **
 ** Version		: 1.0
 ** History		:
 ******************************************************************/
#if !defined(_FILE*NAME_INC_)
#define _FILE*NAME_INC_

#include <xptypes.h>
#include <xpexcept.h>

define_your_macro_or_struct_here

#ifdef __cplusplus
extern "C" {
#endif
	
	declares_your_c_functions_here

#ifdef __cplusplus
};
#endif

#ifdef __cplusplus

	defines_your_c++_class_here

#endif

#endif /*_FILE*NAME_INC_*/

/******************************************************************
 ** File 		: xpsec.h
 ** Author		: */place_your_name_here/*
 ** Date		: 2011-02-27
 ** Copyright	: Copyright (c) 2012-2014 Tencent Co.,Ltd.
 ** Description	: xplatform security library
 **
 ** Version		: 1.0
 ** History		:
 ******************************************************************/
#if !defined(_XPSEC_INC_)
#define _XPSEC_INC_
#pragma once

#include <xptypes.h>
#include <xpexcept.h>

define_your_macro_or_struct_here

#ifdef __cplusplus
extern "C" {
#endif
	
	declares_your_c_functions_here
	
#ifdef __cplusplus
};
#endif

#ifdef __cplusplus

defines_your_c++_class_here

#endif

#endif /*_XPSEC_INC_*/

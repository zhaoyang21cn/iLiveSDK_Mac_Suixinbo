﻿#pragma once

#include <xpstream.h>

XP_NS_BEGIN

namespace xpstl 
{
    typedef xp::strutf8 string;
	typedef xp::strutf16 wstring;
	typedef xp::buffer	buffer;
}

XP_NS_END